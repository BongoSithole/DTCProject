package StepDefinition;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

//import java.util.concurrent.TimeUnit;

public class MyStepDefinition {

    WebDriver driver ;

    @Given("Login using the My Account menu item")
    public void login_using_the_my_account_menu_item() {
        //Launch the application

        System.setProperty("webdriver.edge.driver", "C:\\Users\\F5484863\\OneDrive - FRG\\Desktop\\Automation\\BonganiDTCAssessment\\edge\\msedgedriver.exe");
        driver = new EdgeDriver();

        //System.setProperty("webdriver.chrome.driver", "C:\\Users\\F5484863\\OneDrive - FRG\\Desktop\\Automation\\FaithMasukuNedbankAssessment\\chromedriver-win64\\chromedriver.exe");
        //driver = new ChromeDriver();

        driver.get("https://practicesoftwaretesting.com/");
        driver.manage().window().maximize();
        //driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);




       //Login User
        WebElement btnSignIn = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[4]/a"));
        btnSignIn.click();

        WebElement txtUser = driver.findElement(By.xpath("/html/body/app-root/div/app-login/div/div/div/form/div[1]/input"));
        txtUser.sendKeys("bbsbonganisithole@gmail.com");

        WebElement txtPass = driver.findElement(By.xpath("//*[@id=\"password\"]"));
        txtPass.sendKeys("F(kJ3w1XN1");

        WebElement btn_login = driver.findElement(By.cssSelector("body > app-root > div > app-login > div > div > div > form > div.input-group.mb-3 > input"));
        btn_login.click();




    }
    @When("Go to toolshop and select catergories")
    public void go_to_shop_on_the_menu_bar() {

        WebElement power_tools = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/ul/li[2]/a"));
        power_tools.click();

    }
    @When("Buy a belt sander")
    public void belt_sander(Integer int1) {

        WebElement link_belt = driver.findElement(By.xpath("/html/body/app-root/div/app-category/div[2]/div[2]/div[1]/a[2]/div[1]/img"));
        link_belt.click();

        WebElement btn_addToCart = driver.findElement(By.xpath("//*[@id=\"btn-add-to-cart\"]"));
        btn_addToCart.click();

    }
    @Then("Check out, Place your order")
    public void check_out_place_your_order() throws InterruptedException {


        WebElement btn_cart = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[5]/a/fa-icon"));
        btn_cart.click();
        //driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        WebElement btn_proceedToCheckout = driver.findElement(By.xpath("//button[@id='place_order']"));
        btn_proceedToCheckout.click();
        //driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        WebElement btn_proceedToCheckout2 = driver.findElement(By.xpath("/html/body/app-root/div/app-checkout/aw-wizard/div/aw-wizard-step[2]/app-login/div/div/div/div/button"));
        btn_proceedToCheckout2.click();

        WebElement btn_proceedToCheckout3 = driver.findElement(By.xpath("/html/body/app-root/div/app-checkout/aw-wizard/div/aw-wizard-step[3]/app-address/div/div/div/div/button"));
        btn_proceedToCheckout3.click();

        //Payment type
        WebElement dropdownElement = driver.findElement(By.xpath("//*[@id=\"payment-method\"]"));
        Select dropdown = new Select(dropdownElement);
        dropdown.selectByVisibleText("cash-on-delivery");

        WebElement btn_confirm = driver.findElement(By.xpath("/html/body/app-root/div/app-checkout/aw-wizard/div/aw-wizard-step[3]/app-address/div/div/div/div/button"));
        btn_confirm.click();

        WebElement btn_confirm2 = driver.findElement(By.xpath("/html/body/app-root/div/app-checkout/aw-wizard/div/aw-wizard-completion-step/app-payment/div/div/div/div/button"));
        btn_confirm2.click();

        driver.close();

    }

}
